using UnityEngine;
using UnityAtoms.BaseAtoms;

namespace UnityBoilerplate.UI 
{
    public class BaseScreen : MonoBehaviour
    {
        [SerializeField] GameObject firstHighlightedElement;

        [Header("Event References")]
        [SerializeField] StringEvent screenOpenEvent;
        [SerializeField] VoidEvent screenCloseEvent;

        void Awake()
        {
            if (firstHighlightedElement == null)
            {
                Debug.LogError("Screen: The screen is missing the firstHighlightedElement reference!");
            }
        }

        public void OpenScreen(string name)
        {
            screenOpenEvent.Raise(name);
        }

        public void CloseScreen()
        {
            screenCloseEvent.Raise();
        }

        public GameObject GetFirstHighlightedElement()
        {
            return firstHighlightedElement;
        }
    }
}
