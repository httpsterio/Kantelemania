using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;
using UnityBoilerplate.Audio;

namespace UnityBoilerplate.UI 
{
    public class SettingsScreen : BaseScreen
    {
        [SerializeField] AudioMixer audioMixer;
        [SerializeField] Slider musicVolumeSlider;
        [SerializeField] Slider sfxVolumeSlider;

        private void Awake()
        {
            musicVolumeSlider.onValueChanged.AddListener(OnMusicVolumeChanged);
            sfxVolumeSlider.onValueChanged.AddListener(OnSfxVolumeChanged);

            // Set slider min and max values to match the AudioMixer values
            musicVolumeSlider.minValue = -80;
            musicVolumeSlider.maxValue = 20;
            sfxVolumeSlider.minValue = -80;
            sfxVolumeSlider.maxValue = 20;

            // Set initial slider values from PlayerPrefs
            musicVolumeSlider.value 
                = PlayerPrefs.GetFloat(AudioManager.MUSIC_VOL_PREFS_KEY, 0f);
            sfxVolumeSlider.value 
                = PlayerPrefs.GetFloat(AudioManager.SFX_VOL_PREFS_KEY, 0f);
        }

        private void OnMusicVolumeChanged(float value)
        {
            AudioManager.instance.ChangeMusicVolume(value);
        }

        private void OnSfxVolumeChanged(float value)
        {
            AudioManager.instance.ChangeSfxVolume(value);
        }

        // This is called by the SFX slider then the dragging movement
        // ends. This ensures that the sample sound will be only played
        // once even if the player is dragging the handle with a mouse.
        public void OnSfxSliderChangeEnd() 
        {
            AudioManager.instance.PlaySampleSFX();
        }
    }
}
