using UnityEngine;
using UnityEngine.SceneManagement;
using UnityAtoms.BaseAtoms;

namespace UnityBoilerplate.UI 
{
    public class PauseScreen : BaseScreen
    {
        [SerializeField] VoidEvent resumeGameEvent;

        public void ResumeGameButtonPressed()
        {
            resumeGameEvent.Raise();
        }

        public void ReturnToMenuButtonPressed()
        {
            CloseScreen();
            SceneManager.LoadScene("Menu");
        }
    }
}