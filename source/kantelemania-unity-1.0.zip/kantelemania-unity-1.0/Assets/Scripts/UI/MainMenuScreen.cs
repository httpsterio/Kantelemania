using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityAtoms.BaseAtoms;

namespace UnityBoilerplate.UI 
{
    public class MainMenuScreen : BaseScreen
    {
        [SerializeField] VoidEvent startGameEvent;

        public void StartGameButtonPressed()
        {
            startGameEvent.Raise();
        }
    }
}