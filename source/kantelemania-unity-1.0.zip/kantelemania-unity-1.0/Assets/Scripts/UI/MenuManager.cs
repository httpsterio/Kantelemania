using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityAtoms.BaseAtoms;

namespace UnityBoilerplate.UI
{
    [DisallowMultipleComponent]
    public class MenuManager : MonoBehaviour
    {
        public static MenuManager instance;

        [SerializeField]
        private List<MenuScreen> screens = new List<MenuScreen>();

        private Stack<MenuScreen> screenStack = new Stack<MenuScreen>();
        private Stack<GameObject> highlightStack = new Stack<GameObject>();

        [SerializeField]
        private PlayerInput playerInput;
        private InputAction cancelAction;

        private bool gameIsRunning = true;

        [Header("Event References")]
        [SerializeField] private VoidEvent resumeAction;

        #region "Initialisation"
        private void Awake() 
        {
            if (instance == null)
            {
                instance = this;
            }
            else 
            {
                Destroy(gameObject);
            }

            cancelAction = playerInput.actions["Cancel"];
        }

        private void OnEnable()
        {
            SceneManager.sceneLoaded += OnSceneLoad;
            cancelAction.performed += OnCancelAction;
        }

        private void OnDisable() 
        {
            SceneManager.sceneLoaded -= OnSceneLoad;
            cancelAction.performed -= OnCancelAction;
        }

        private void OnSceneLoad(Scene scene, LoadSceneMode mode)
        {
            if (scene.name == "Menu")
            {
                gameIsRunning = false;
                OpenScreen("Screen_MainMenu");
            }
        }

        void Start()
        {
            if (screens.Count == 0) 
            {
                Debug.LogError("MenuManager: The screen array is empty.");
                return;
            }
        }
        #endregion
        
        public void OpenScreen(string name)
        {
            MenuScreen screen = FindMenuScreen(name);
            if (screen == null)
            {
                Debug.LogError("MenuManager: Cannot find a screen with a name " + name);
                return;
            }

            OpenScreen(screen);
        }

        public void OpenScreen(MenuScreen screen)
        {
            // Check if the current screen should be destroyed first
            // TODO: May want to delay screen destruction if there is an animation
            //       for the next screen
            if (screenStack.Count > 0)
            {
                MenuScreen current = screenStack.Peek();
                if (current.destroyOnNewScreenOpen) 
                {
                    CloseScreen();
                }

                AddToHighlightHistory();
            }

            GameObject canvas = Instantiate(screen.prefab, transform);
            screen.instance = canvas;
            screenStack.Push(screen);

            if (screen.name == "Screen_GameOver")
                playerInput.SwitchCurrentActionMap("UI");

            UpdateHighlightedElement();
        }

        public void CloseScreen()
        {
            if (screenStack.Count == 0) return;

            if (screenStack.Count == 1 && !gameIsRunning) 
            {
                Debug.LogWarning("MenuManager: The last screen cannot be closed when in menu.");
                return;
            }

            MenuScreen screenToClose = screenStack.Pop();
            Destroy(screenToClose.instance);

            RestoreHighlightedElement();
        }

        public void CloseAllScreens()
        {
            for (int i = 0; i <= screenStack.Count; i++)
            {
                CloseScreen();
            }
        }

        public void StartGame()
        {
            gameIsRunning = true;
            CloseAllScreens();
        }

        private MenuScreen FindMenuScreen(string name)
        {
            return screens.Find(s => s.name == name);
        }

        private void UpdateHighlightedElement()
        {   
            GameObject newHighlightedElement = screenStack.Peek()
                .instance
                .GetComponent<BaseScreen>()
                .GetFirstHighlightedElement();

            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(newHighlightedElement);
        }

        private void AddToHighlightHistory()
        {
            if (EventSystem.current.currentSelectedGameObject != null)
            {
                highlightStack.Push(EventSystem.current.currentSelectedGameObject);
            }
        }

        private void RestoreHighlightedElement()
        {
            if (highlightStack.Count <= 0) return;

            GameObject newHighlightedElement = highlightStack.Pop();

            EventSystem.current.SetSelectedGameObject(null);
            EventSystem.current.SetSelectedGameObject(newHighlightedElement);
        }

        private void OnCancelAction(InputAction.CallbackContext _)
        {
            if (screenStack.Count == 0)
            {
                Debug.LogError("MenuManager: Cancel action called when there are no screens.");
                return;
            }

            if (screenStack.Peek().name == "Screen_Pause")
            {
                resumeAction.Raise();
                CloseScreen();
            }
            else
            {
                CloseScreen();
            }
        }
    }
}

