using UnityEngine;
using UnityEngine.SceneManagement;
using UnityAtoms.BaseAtoms;

namespace UnityBoilerplate.UI 
{
    public class GameOverScreen : BaseScreen
    {
        [SerializeField] VoidEvent startGameEvent;
    
        public void RestartGameButtonPressed()
        {
            CloseScreen();
            SceneManager.LoadScene("Game");
        }

        public void ReturnToMenuButtonPressed()
        {
            CloseScreen();
            SceneManager.LoadScene("Menu");
        }
    }
}