using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using MoreMountains.Feedbacks;
using TMPro;

public class ScoreCounter : MonoBehaviour
{
    public MMF_Player Feedback;
    TextMeshProUGUI text;

    void Awake()
    {
        text = GetComponent<TextMeshProUGUI>();
        //Feedback?.Initialization();
    }

    public void AddScore(float turha)
    {
        if (text != null)
        {
            var oldText = text.text;
            var score = int.Parse(oldText);
            ++score;
            text.text = score.ToString();

            Feedback?.PlayFeedbacks();
        }
    }
}
