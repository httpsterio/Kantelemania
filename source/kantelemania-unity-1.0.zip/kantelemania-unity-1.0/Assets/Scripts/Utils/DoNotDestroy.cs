using UnityEngine;

namespace UnityBoilerplate.Utils 
{
    public class DoNotDestroy : MonoBehaviour
    {
        
    void Start()
    {
        DontDestroyOnLoad(gameObject);
    }
}
}

