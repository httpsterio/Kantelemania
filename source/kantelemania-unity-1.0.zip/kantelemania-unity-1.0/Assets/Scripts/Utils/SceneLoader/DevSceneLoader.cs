using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class DevSceneLoader : MonoBehaviour
{
    [SerializeField] private SceneInfo sceneInfo;
    [SerializeField] private PlayerInput playerInput;
    // Start is called before the first frame update
    void Start()
    {
        playerInput.enabled = false;
        SceneManager.LoadScene(sceneInfo.sceneName);
    }
}
