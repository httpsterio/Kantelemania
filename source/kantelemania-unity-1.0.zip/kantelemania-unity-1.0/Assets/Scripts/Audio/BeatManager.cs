using UnityEngine;
using UnityAtoms.BaseAtoms;
using System.Collections;

namespace GGJ
{
    public class BeatManager : MonoBehaviour
    {
        public static BeatManager instance;

        [Header("Song Configuration")]
        // Song beats per minute
        public float songBpm;

        // The number of beats per bar
        public float beatsPerBar = 4f;

        [Header("Timing Configuration")]
        public float perfectThreshold = 0.05f;
        public float goodThreshold = 0.1f;

        // The number of seconds for each song beat
        private float secPerBeat;
        private float secPerHalfBeat;

        // Current song position, in seconds
        private float songPosition;

        [SerializeField] private float songPositionInHalfBeats = 0f;
        public float SongPositionInHalfBeats {
            get {
                return songPositionInHalfBeats;
            }
        }
        private int positionInHalfBeatsAsInt = 0;

        // Current song position, in 1/4 notes
        [SerializeField] private float songPositionInBeats = 0f;
        public float SongPositionInBeats {
            get {
                return songPositionInBeats;
            }
        }
        private int positionInBeatsAsInt = 0;

        // Current song position, in bars
        [SerializeField] private float songPositionInBars = 0f;
        private int positionInBarsAsInt = 0;

        // Seconds have passed since the song started
        private float songStartTime;

        // An AudioSource that will play the music

        [SerializeField] private AudioSource mainSource;
        [SerializeField] private AudioSource hypeSource;

        [Header("Event References")]
        [SerializeField] IntEvent halfBeatEvent;
        [SerializeField] IntEvent beatEvent;
        [SerializeField] IntEvent barEvent;

        void Awake()
        {
            if (instance == null)
            {
                instance = this;
            }
            else 
            {
                Destroy(gameObject);
            }
        }

        void Start()
        {
            mainSource = GetComponentInChildren<AudioSource>();

            // Calculate the number of seconds in each beat
            secPerBeat = 60f / songBpm;
            secPerHalfBeat = secPerBeat / 2;

            // Save the audio start time
            songStartTime = (float)AudioSettings.dspTime;

            mainSource.Play();
            hypeSource.Play();
        }

        void Update()
        {
            songPosition = (float)(AudioSettings.dspTime - songStartTime);

            songPositionInHalfBeats = songPosition / secPerHalfBeat;

            songPositionInBeats = songPosition / secPerBeat;

            songPositionInBars = songPositionInBeats / beatsPerBar;

            if (Mathf.FloorToInt(songPositionInHalfBeats) > positionInHalfBeatsAsInt)
            {
                ++positionInHalfBeatsAsInt;
                halfBeatEvent.Raise(positionInHalfBeatsAsInt);
            }

            if (Mathf.FloorToInt(songPositionInBeats) > positionInBeatsAsInt)
            {
                ++positionInBeatsAsInt;
                beatEvent.Raise(positionInBeatsAsInt);
            }

            if (Mathf.FloorToInt(songPositionInBars) > (positionInBarsAsInt))
            {
                ++positionInBarsAsInt;
                barEvent.Raise(positionInBarsAsInt);
            }
        }

        public TimingResult CheckHalfBeatProximity(float halfBeat)
        {
            string feedback;

            float actionTime = songPositionInHalfBeats;
            float beatToCompareTo = halfBeat;
            float difference = actionTime - beatToCompareTo;
            float absDifference = Mathf.Abs(difference);

            if (absDifference <= perfectThreshold)
            {
                feedback = "Perfect!";
            }
            else if (absDifference <= goodThreshold)
            {
                feedback = "Good!";
            }
            else
            {
                if (difference < 0f)
                {
                    feedback = "Too early!";
                }
                else
                {
                    feedback = "Too late!";
                }
            }
            
            return new TimingResult(difference, feedback);
        }

        public float CheckBeatProximity(float beat)
        {
            float actionTime = songPositionInBeats;
            float beatToCompareTo = beat;
            float difference = actionTime - beatToCompareTo;
            float absDifference = Mathf.Abs(difference);

            /*
            if (absDifference <= perfectThreshold)
            {
                feedback = "Perfect!";
            }
            else if (absDifference <= goodThreshold)
            {
                feedback = "Good!";
            }
            else
            {
                if (difference < 0f)
                {
                    feedback = "Too early!";
                }
                else
                {
                    feedback = "Too late!";
                }
            }
            */
            
            return difference;
        }

        public TimingResult CheckBarProximity()
        {
            string feedback;

            float actionTime = songPositionInBars;
            float closestBar = Mathf.Round(actionTime);
            float difference = actionTime - closestBar;
            float absDifference = Mathf.Abs(difference);

            if (absDifference <= perfectThreshold)
            {
                feedback = "Perfect!";
            }
            else if (absDifference <= goodThreshold)
            {
                feedback = "Good!";
            }
            else
            {
                if (difference < 0f)
                {
                    feedback = "Too early!";
                }
                else
                {
                    feedback = "Too late!";
                }
            }
            
            return new TimingResult(difference, feedback);
        }

        public void OnPause()
        {
            mainSource.Pause();
            hypeSource.Pause();
        }

        public void OnResume()
        {
            mainSource.UnPause();
            hypeSource.UnPause();
        }

        public static IEnumerator FadeTrack(AudioSource audioSource, float duration, float targetVolume)
        {
            float currentTime = 0;
            float start = audioSource.volume;
            while (currentTime < duration)
            {
                currentTime += Time.deltaTime;
                audioSource.volume = Mathf.Lerp(start, targetVolume, currentTime / duration);
                yield return null;
            }
            yield break;
        }

        public void ToggleHype(bool hype)
        {
            if (hype)
            {
                StartCoroutine(FadeTrack(hypeSource, 3f, .75f));
            }
            else
            {
                StartCoroutine(FadeTrack(hypeSource, 3f, 0));
            }
        }
    }



    public struct TimingResult 
    {
        public float difference;
        public string feedback;

        public TimingResult(float diff, string fb)
        {
            this.difference = diff;
            this.feedback = fb;
        }
    }
}