using UnityEngine;
using UnityEngine.Audio;

namespace UnityBoilerplate.Audio
{
    [RequireComponent(typeof(AudioSource))]
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager instance;

        [SerializeField] private AudioMixer audioMixer;
        private AudioSource sampleAudioSource;
        [SerializeField] private AudioClip sampleSfx;

        // String keys for the AudioMixer groups
        public const string MIXER_MUSIC_KEY = "MusicVolume";
        public const string MIXER_SFX_KEY = "SfxVolume";

        // String keys for the PlayerPrefs values
        public const string MUSIC_VOL_PREFS_KEY = "MusicVolume";
        public const string SFX_VOL_PREFS_KEY = "SfxVolume";

        private void Awake() 
        {
            if (instance == null)
            {
                instance = this;
            }
            else 
            {
                Destroy(gameObject);
            }

            if (audioMixer == null)
            {
                Debug.LogError("AudioManager: The AudioMixer reference is not set!");
                return;
            }

            sampleAudioSource = GetComponent<AudioSource>();

            LoadAndSetVolumes();
        }

        private void LoadAndSetVolumes()
        {
            float playerMusicVolume = PlayerPrefs.GetFloat(MUSIC_VOL_PREFS_KEY, -3.8f);
            float playerSfxVolume = PlayerPrefs.GetFloat(SFX_VOL_PREFS_KEY, -4f);

            audioMixer.SetFloat(MIXER_MUSIC_KEY, playerMusicVolume);
            audioMixer.SetFloat(MIXER_SFX_KEY, playerSfxVolume);
        }

        public void ChangeMusicVolume(float value)
        {
            audioMixer.SetFloat(MIXER_MUSIC_KEY, value);
            PlayerPrefs.SetFloat(MUSIC_VOL_PREFS_KEY, value);
        }

        public void ChangeSfxVolume(float value)
        {
            audioMixer.SetFloat(MIXER_SFX_KEY, value);
            PlayerPrefs.SetFloat(SFX_VOL_PREFS_KEY, value);
        }

        // This is called when the player changes the SFX volume.
        // The sample effect is played so the player can immediately
        // evaluate how the change affected the volume.
        public void PlaySampleSFX()
        {
            if (sampleSfx == null)
            {
                Debug.LogWarning("AudioManager: Sample SFX clip is not set. Nothing will be played.");
                return;
            }

            sampleAudioSource.PlayOneShot(sampleSfx);
        }
    }
}
