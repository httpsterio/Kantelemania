using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Users;
using UnityEngine.SceneManagement;

namespace UnityBoilerplate.Input
{
    public class InputManager : MonoBehaviour
    {
        public static InputManager instance;

        private PlayerInput playerInput;

        #region Initialisation
        private void Awake() 
        {
            if (instance == null)
            {
                instance = this;
            }
            else 
            {
                Destroy(gameObject);
            }

            playerInput = GetComponent<PlayerInput>();
        }

        private void OnEnable()
        {
            SceneManager.sceneLoaded += OnSceneLoad;
            InputUser.onChange += OnInputUserChange;
        }

        private void OnDisable() 
        {
            SceneManager.sceneLoaded -= OnSceneLoad;
            InputUser.onChange -= OnInputUserChange;
        }

        private void OnSceneLoad(Scene scene, LoadSceneMode mode)
        {
            // NOTE: This is an attempt to fix a bug where action maps do 
            // not work correctly after the scene load from the Manager scene
            playerInput.enabled = true;

            if (scene.name == "Menu")
            {
               playerInput.SwitchCurrentActionMap("UI");
            }
            else 
            {
                playerInput.SwitchCurrentActionMap("Game");
            }
        }
        #endregion

        private void OnInputUserChange(InputUser user, InputUserChange change, InputDevice device)
        {
            if (change == InputUserChange.ControlSchemeChanged)
            {
                // TODO: Find a way to reference control schemes without string manipulation
                string scheme = user.controlScheme.ToString();
                int index = scheme.IndexOf("(");
                if (index >= 0)
                    scheme = scheme.Substring(0, index);

                Debug.Log("InputManager: Control scheme changed to " + scheme);

                // TODO: Change a some kind of event that the scheme has changed so other
                // objects can react to it if needed.
            }
        }

        public void ChangeToUIActionMap()
        {
            playerInput.SwitchCurrentActionMap("UI");
        }

        public void ChangeToGameActionMap()
        {
            playerInput.SwitchCurrentActionMap("Game");
        }
    }
}

