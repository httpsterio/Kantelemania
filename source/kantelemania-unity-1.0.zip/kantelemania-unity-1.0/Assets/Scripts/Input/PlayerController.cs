using UnityEngine;
using UnityEngine.InputSystem;
using MoreMountains.Feedbacks;
using GGJ;

namespace UnityBoilerplate.Input
{
    [RequireComponent(typeof(Rigidbody2D))]
    public class PlayerController : MonoBehaviour
    {   
        private PlayerInput playerInput;

        //private InputAction playAction;
        private InputAction upAction;
        private InputAction downAction;
        private InputAction leftAction;
        private InputAction rightAction;

        private NoteSpawner noteSpawner;

        private void Awake()
        {
            // TODO: Remove this (inefficient)
            playerInput = GameObject.Find("Input Manager").GetComponent<PlayerInput>();
            noteSpawner = GameObject.Find("NoteSpawner").GetComponent<NoteSpawner>();

            //playAction = playerInput.actions["Play"];
            upAction = playerInput.actions["Up"];
            downAction = playerInput.actions["Down"];
            leftAction = playerInput.actions["Left"];
            rightAction = playerInput.actions["Right"];
        }

        private void OnEnable()
        {
            // NOTE: Using the lambda expression (ctx => OnJump(ctx))
            // usually is not smart because it is really hard to unsubscribe
            // from lambda expressions.
            // See: https://stackoverflow.com/questions/1362204/how-to-remove-a-lambda-event-handler

            // Subscribe to events
            //playAction.performed += OnPlayAction;
            upAction.performed += OnDirectionAction;
            downAction.performed += OnDirectionAction;
            leftAction.performed += OnDirectionAction;
            rightAction.performed += OnDirectionAction;
        }

        private void OnDisable()
        {
            // Unsubscribe from events
            //playAction.performed -= OnPlayAction;
            upAction.performed -= OnDirectionAction;
            downAction.performed -= OnDirectionAction;
            leftAction.performed -= OnDirectionAction;
            rightAction.performed -= OnDirectionAction;
            
        }
        
        //private void OnPlayAction(InputAction.CallbackContext context)
        //{
        //    if (context.ReadValueAsButton())
        //    {
        //        //noteSpawner.PlayANote();
        //    }
        //}

        private void OnDirectionAction(InputAction.CallbackContext context)
        {
            if (context.ReadValueAsButton())
            {
                switch (context.action.name)
                {
                    case "Up":
                        noteSpawner.PlayANote(NoteDirection.Up);
                        break;
                    case "Down":
                        noteSpawner.PlayANote(NoteDirection.Down);
                        break;
                    case "Left":
                        noteSpawner.PlayANote(NoteDirection.Left);
                        break;
                    case "Right":
                        noteSpawner.PlayANote(NoteDirection.Right);
                        break;
                    default: 
                        break;
                }
            }
        }
    } 
}
