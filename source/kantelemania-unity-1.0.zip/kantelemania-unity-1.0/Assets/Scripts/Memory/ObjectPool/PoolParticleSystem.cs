using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UnityBoilerplate.Memory
{
    [RequireComponent(typeof(ParticleSystem))]
    public class PoolParticleSystem : PoolObject
    {
        private ParticleSystem particles;

        private void Awake() 
        {
            particles = GetComponent<ParticleSystem>();
            var main = particles.main;
            main.stopAction = ParticleSystemStopAction.Callback;
        }

        public override void OnReuse() 
        { 
            particles.Clear();
            particles.Play();
        }

        public override void OnRelease() 
        { 
            particles.Clear();
        }

        // This callback gets called when the particle system stops
        void OnParticleSystemStopped()
        {
            Release();
        }
    }
}

