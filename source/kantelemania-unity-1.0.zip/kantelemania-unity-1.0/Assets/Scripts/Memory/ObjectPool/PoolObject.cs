using UnityEngine;
using UnityEngine.Pool;

namespace UnityBoilerplate.Memory
{
    public class PoolObject : MonoBehaviour
    {
        private ObjectPool poolReference;

        public void SetPoolReference(ObjectPool reference)
        {
            poolReference = reference;
        }

        public void Release()
        {
            poolReference.ReleaseObject(gameObject);
        }

        public virtual void OnReuse() { }

        public virtual void OnRelease() { }
    }   
}

