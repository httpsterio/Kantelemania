using UnityEngine;
using UnityEngine.Pool;

namespace UnityBoilerplate.Memory
{
    public class ObjectPool : MonoBehaviour
    {
        [SerializeField] private bool debug = false;

        [Header("Config")]
        [SerializeField]
        private PoolObject objectPrefab;

        [Tooltip("The initial amount of objects initialized to the pool.")]
        [SerializeField] private int initialPoolSize = 10;
        [Tooltip("When the pool reaches its max size, all further instances returned to the pool will be ignored and destoryed.")]
        [SerializeField] private int maxPoolSize = 100;
        [Tooltip("Check whether an object being returned to the pool already exists in the pool.")]
        [SerializeField] private bool enableCollectionChecks = true;

        private ObjectPool<GameObject> pool;
  
        private void Awake()
        {
            pool = new ObjectPool<GameObject>(CreatePoolObject, OnObjectGet, 
                OnObjectRelease, OnObjectDestroy, enableCollectionChecks, 
                initialPoolSize, maxPoolSize);
        }

        public GameObject GetObject()
        {
            return pool.Get();
        }

        public void ReleaseObject(GameObject obj) 
        {
            pool.Release(obj);
        }

        private GameObject CreatePoolObject()
        {
            GameObject obj = Instantiate(objectPrefab.gameObject);
            obj.GetComponent<PoolObject>().SetPoolReference(this);
            return obj;
        }

        private void OnObjectGet(GameObject obj)
        {
            obj.SetActive(true);
            obj.GetComponent<PoolObject>().OnReuse();
        }

        private void OnObjectRelease(GameObject obj)
        {
            obj.SetActive(false);
            obj.GetComponent<PoolObject>().OnRelease();
        }

        private void OnObjectDestroy(GameObject obj)
        {
            Destroy(obj);
        }

        void OnGUI()
        {
            if (debug) 
            {
                GUILayout.Label("Active pool objects: " + pool.CountActive);
                GUILayout.Label("Available pool objects: " + pool.CountInactive);
            }
        }
    }
}

