using UnityEngine;
using UnityBoilerplate.Memory;

namespace UnityBoilerplate.Memory 
{
    public class ExampleSpawner : MonoBehaviour
    {
        private ObjectPool objectPool;
        [SerializeField] private bool spawn = true;

        private void Awake() 
        {
            objectPool = GetComponent<ObjectPool>();
        }

        private void Update() 
        {
            if (!spawn) return;

            GameObject obj = objectPool.GetObject();
            obj.transform.SetPositionAndRotation(transform.position, transform.rotation);
        }
    }
}
