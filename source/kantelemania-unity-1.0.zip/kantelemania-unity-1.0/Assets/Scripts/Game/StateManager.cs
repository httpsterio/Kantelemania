using System.Collections.Generic;
using UnityEngine;
using UnityAtoms.BaseAtoms;

namespace UnityBoilerplate.State
{
    [DisallowMultipleComponent]
    public class StateManager : MonoBehaviour
    {
        [SerializeField] private GameState currentState;
        [SerializeField] private GameState lastState;

        [SerializeField]
        private List<GameState> possibleStates = new List<GameState>();

        [Header("Event References")]
        [SerializeField] private VoidEvent gameResumeEvent;

        public GameState CurrentState
        {
            get { return currentState; }
        }

        public GameState LastState
        {
            get { return lastState; }
        }

        private bool ChangeState(GameState nextState)
        {
            if (nextState == currentState)
                return false;

            lastState = currentState;
            currentState = nextState;

            RaiseStateChangeEvent(nextState);

            return true;
        }

        private GameState FindGameState(string name)
        {
            return possibleStates.Find(s => s.name == name);
        }

        private void RaiseStateChangeEvent(GameState state)
        {
            state.onStateChangeEvent.Raise();
        }

        public bool ChangeState(string nextStateName)
        {
            GameState nextState = FindGameState(nextStateName);

            return ChangeState(nextState);
        }

        public bool RewindToLastState()
        {
            if (lastState == null)
            {
                Debug.LogError("StateManager: Cannot rewind when the last state is null.");
                return false;
            }

            if (currentState.name == "State_Pause")
            {
                gameResumeEvent.Raise();
            }

            return ChangeState(lastState);
        }
    }
}