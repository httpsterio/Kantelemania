using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityAtoms.BaseAtoms;

using UnityBoilerplate.State;

[DisallowMultipleComponent]
[RequireComponent(typeof(StateManager))]
public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [SerializeField] private StateManager stateManager;

    [Header("Event References")]
    [SerializeField] private VoidEvent cancelEvent;

    [SerializeField] private PlayerInput playerInput;
    private InputAction pauseAction; 

    #region "Initialisation"
    private void Awake() 
    {
        if (instance == null)
        {
            instance = this;
        }
        else 
        {
            Destroy(gameObject);
        }

        Application.runInBackground = true;

        stateManager = GetComponent<StateManager>();

        pauseAction = playerInput.actions["Pause"];
    }

    private void OnEnable() 
    {
        SceneManager.sceneLoaded += OnSceneLoad;
        pauseAction.performed += OnPauseAction;
    }

    private void OnDisable() {
        SceneManager.sceneLoaded -= OnSceneLoad;
    }

    private void OnSceneLoad(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "Menu")
        {
            stateManager.ChangeState("State_Menu");
        }
        else if (scene.name == "Game")
        {
            stateManager.ChangeState("State_Game");
        }
    }

    void Start()
    {
        if (SceneManager.GetActiveScene().name == "Menu")
        {
            stateManager.ChangeState("State_Menu");
        }
        else 
        {
            stateManager.ChangeState("State_Game");
        }
    }
    #endregion

    public void StartGame()
    {
        SceneManager.LoadScene("Game");
        stateManager.ChangeState("State_Game");
    }

    private void OnPauseAction(InputAction.CallbackContext _)
    {
        PauseGame();
    }

    public void PauseGame()
    {
        if (stateManager.CurrentState.name == "State_Pause")
        {
            Debug.LogWarning("GameManager: The game is already paused!");
            return;
        }

        if (!stateManager.CurrentState.allowsPausing)
        {
            Debug.LogWarning("GameManager: The current state " 
                + stateManager.CurrentState.name + " cannot be paused!");
            return;
        }

        Time.timeScale = 0;
        stateManager.ChangeState("State_Pause");
    }

    public void ResumeGame()
    {
        if (stateManager.CurrentState.name == "State_Pause")
        {
            Time.timeScale = 1;
            stateManager.RewindToLastState();
        }
    }

    public void OnGameEnd()
    {
        stateManager.ChangeState("State_End");
    }
}
