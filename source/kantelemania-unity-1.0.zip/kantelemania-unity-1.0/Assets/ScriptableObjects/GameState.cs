using UnityEngine;
using UnityAtoms.BaseAtoms;

[CreateAssetMenu(fileName = "GameState", menuName = "Data/GameState")]
public class GameState : ScriptableObject
{
    public VoidEvent onStateChangeEvent;
    public bool allowsPausing;
}