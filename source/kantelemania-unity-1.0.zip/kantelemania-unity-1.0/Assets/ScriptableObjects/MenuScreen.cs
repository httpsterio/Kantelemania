using UnityEngine;

[CreateAssetMenu(fileName = "MenuScreen", menuName = "Data/UI/MenuScreen")]
public class MenuScreen : ScriptableObject
{
    public GameObject prefab;
    public GameObject instance;
    public bool destroyOnNewScreenOpen;
    public bool transitionIn;
    public bool transitionOut;
}
