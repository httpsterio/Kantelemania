using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlassesController : MonoBehaviour
{
    private Animator animator;

    void Start() 
    {
        animator = GetComponent<Animator>();
    }

    public void ToggleGlasses(bool hype)
    {
        animator.SetBool("Glasses", hype);
    }
}
