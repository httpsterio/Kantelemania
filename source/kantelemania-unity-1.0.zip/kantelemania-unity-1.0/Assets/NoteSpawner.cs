using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityAtoms.BaseAtoms;

namespace GGJ 
{
    [System.Serializable]
    public class NotePlayOrder {
        public float startTime;
        public NoteCombo comboNotes;
    }

    public class NoteSpawner : MonoBehaviour
    {
        public float comboSpawnHeadStart = 8f;
        [SerializeField] GameObject notePrefab;
        [SerializeField] List<NotePlayOrder> combos = new List<NotePlayOrder>();
        [SerializeField] NotePlayOrder currentCombo;

        [SerializeField] private AudioSource audioSource;

        public float PenaltyFromExpiringNote = 10.0f;
        public float PenaltyFromWrongButton = 10.0f;
        [SerializeField] FloatEvent DecreaseScoreEvent;

        // OLD
        //List<GameObject> notesStorage = new List<GameObject>();

        List<GameObject> notesStorage_UP = new List<GameObject>();
        List<GameObject> notesStorage_DOWN = new List<GameObject>();
        List<GameObject> notesStorage_LEFT = new List<GameObject>();
        List<GameObject> notesStorage_RIGHT = new List<GameObject>();

        List<GameObject> notesTemp = new List<GameObject>();

        Transform transformRef;
        bool emptyQueue = false;

        public int NotesPlayed = 0; // "Player Score"
        public int NotesSpawned = 0;
        int makeSpawningFasterPerNotes = 5;

        float spawnNoteTimerBase = 5.0f;
        float spawnNoteTimer = 0.0f;

        void Start()
        {
            if (combos.Count == 0)
            {
                Debug.LogError("NoteSpawner: No play orders in queue!");
            }

            transformRef = GetComponent<Transform>();
            GetNextCombo();
        }

        private void GetNextCombo()
        {
            if (combos.Count == 0)
            {
                Debug.Log("NoteSpawner: Play queue is empty.");
                emptyQueue = true;
                return;
            }

            currentCombo = combos[0];
            combos.RemoveAt(0);
        }

        void Update()
        {
            //SpawnNotesOld();
            SpawnNotesNew();
        }

        void SpawnNotesNew()
        {
            //List<GameObject> notesTemp = new List<GameObject>();
            if (spawnNoteTimer > spawnNoteTimerBase)
            {
                //var visualNote = notePrefab.GetComponent<VisualNote>();
                //visualNote.explodesOnBeat = currentCombo.startTime + n.explodeBeatDelay;
                //visualNote.playOnExplode = n.playOnExplode;
                var note = Instantiate(notePrefab, transformRef.position, Quaternion.identity);
                notesTemp.Add(note);
                spawnNoteTimer = 0.0f;

                //if(note != null)
                //    Debug.Log("Note Spawned!");
            }
            else
            {
                spawnNoteTimer += (Time.deltaTime * Random.Range(1, 10));
            }

            if (notesTemp.Count > 0)
                ThrowNotesInTheAir();
        }

        bool firstTimeUnderTwo = false;
        bool firstTimeUnderOne = false;

        float waitTime = 0.0f;
        float randomWaitTime = 0.0f;
        void ThrowNotesInTheAir()
        {
            if(notesTemp.Count > 0)
            {
                waitTime += Time.deltaTime;
                if (waitTime > randomWaitTime)
                {
                    waitTime = 0.0f;
                    randomWaitTime = Random.Range(0.1f, 0.5f);

                    // Note into air

                    // 1. Valitaan random piste spawnerin ymparilta
                    // 2. Valitaan random piste spawnerin positio + hattuvako
                    // 3. Pisteista muodostuu voimavektori johon suutaan annetaan impulssi

                    int notesPerSpawn = Random.Range(0, notesTemp.Count);
                    for (int i = 0; i < notesPerSpawn; i++)
                    {
                        var note = notesTemp[0];
                        notesTemp.RemoveAt(0);
                        StoreNoteAndSetItsDirection(note);

                        Vector3 pos = Random.insideUnitCircle * 8;
                        var startPos = transformRef.position + pos;

                        pos = Random.insideUnitCircle * 1;
                        pos.y += 5; // hattuvakio
                        var targetPos = transformRef.position + pos;

                        var impulseVector = targetPos - startPos;
                        float impulseForce = (20 - impulseVector.magnitude) * Random.Range(1.1f, 1.3f);

                        var rbody = note.GetComponent<Rigidbody2D>();
                        rbody.simulated = true;
                        rbody.AddForce(Vector2.up * impulseForce, ForceMode2D.Impulse);   // Up Force
                        rbody.AddForce(impulseVector, ForceMode2D.Impulse);               // Left / Right Force

                        //Debug.DrawLine(startPos, targetPos, Color.red, 100f);

                        ++NotesSpawned;
                        if (NotesSpawned % makeSpawningFasterPerNotes == 0)
                        {
                            if (spawnNoteTimerBase > 2.0f)
                            {
                                if (!firstTimeUnderTwo)
                                {
                                    makeSpawningFasterPerNotes = makeSpawningFasterPerNotes * 2;
                                    firstTimeUnderTwo = true;
                                }

                                spawnNoteTimerBase -= (Time.deltaTime * 12);
                            }
                            else if (spawnNoteTimerBase > 1.0f)
                            {
                                if (!firstTimeUnderOne)
                                {
                                    makeSpawningFasterPerNotes = makeSpawningFasterPerNotes * 2;
                                    firstTimeUnderOne = true;
                                }

                                spawnNoteTimerBase -= (Time.deltaTime * 3);
                            }
                            else
                                spawnNoteTimerBase -= Time.deltaTime;
                        }
                    }
                }
            }
        }

        void StoreNoteAndSetItsDirection(GameObject note)
        {
            var visualNote = note.GetComponent<VisualNote>();
            var randomDir = (NoteDirection)Random.Range(0, 4);
            visualNote.SetDirection(randomDir);

            // Store to right storage
            GetNoteStorageRef(randomDir).Add(note);
        }

        ref List<GameObject> GetNoteStorageRef(NoteDirection direction)
        {
            switch (direction)
            {
                case NoteDirection.Up:
                    return ref notesStorage_UP;
                case NoteDirection.Down:
                    return ref notesStorage_DOWN;
                case NoteDirection.Left:
                    return ref notesStorage_LEFT;
                default:
                    return ref notesStorage_RIGHT;
            }
        }

        public void PlayANote(NoteDirection direction)
        {
            var storage = GetNoteStorageRef(direction);
            for (int i = 0; i < storage.Count; i++)
            {
                VisualNote note = storage[i].GetComponent<VisualNote>();
                if (!note.inactive)
                {
                    note.Explode();
                    storage.Remove(storage[i].gameObject);

                    ++NotesPlayed;
                    return;
                }
            }

            audioSource.PlayOneShot(GamePrefabs.Instance.GameElements.MissSound[Random.Range(0, GamePrefabs.Instance.GameElements.MissSound.Length)], 1);
            DecreaseScoreEvent.Raise(PenaltyFromWrongButton);
        }

        // This is called when ExpiredNote Event is rised
        public void RemoveExpiredNote(GameObject note)
        {
            var direction = note.GetComponent<VisualNote>().Direction;
            GetNoteStorageRef(direction).Remove(note);

            DecreaseScoreEvent.Raise(PenaltyFromExpiringNote);
        }
    }

    // DEPRECATED UNDER

    //void SpawnNotesOld()
    //{
    //    if (!emptyQueue && currentCombo != null)
    //    {
    //        float songPosition = BeatManager.instance.SongPositionInBeats;
    //        if ((currentCombo.startTime - comboSpawnHeadStart) < songPosition)
    //        {
    //            // Instantioi ja spawnaa notet ilman fysiikka simulaatiota
    //            List<GameObject> notesTemp = new List<GameObject>();
    //            foreach (Note n in currentCombo.comboNotes.notes)
    //            {
    //                var visualNote = notePrefab.GetComponent<VisualNote>();
    //                visualNote.explodesOnBeat = currentCombo.startTime + n.explodeBeatDelay;
    //                visualNote.playOnExplode = n.playOnExplode;
    //                var note = Instantiate(notePrefab, transformRef.position, Quaternion.identity);

    //                notesTemp.Add(note);
    //            }

    //            if (notesTemp.Count > 0)
    //                StartCoroutine(ThrowNotesInTheAir(notesTemp));

    //            GetNextCombo();
    //        }
    //    }
    //}

    //IEnumerator ThrowNotesInTheAir(List<GameObject> notesTemp)
    //{
    //    float waitTime = 0.0f;
    //    float randomWaitTime = 0.0f;
    //    while (notesTemp.Count > 0)
    //    {
    //        waitTime += Time.deltaTime;
    //        if (waitTime > randomWaitTime)
    //        {
    //            waitTime = 0.0f;
    //            randomWaitTime = Random.Range(0.1f, 0.5f);

    //            // Note into air

    //            // 1. Valitaan random piste spawnerin ymparilta
    //            // 2. Valitaan random piste spawnerin positio + hattuvako
    //            // 3. Pisteista muodostuu voimavektori johon suutaan annetaan impulssi

    //            var note = notesTemp[0];
    //            StoreNoteAndSetItsDirection(note);
    //            notesTemp.RemoveAt(0);

    //            Vector3 pos = Random.insideUnitCircle * 8;
    //            var startPos = transformRef.position + pos;

    //            pos = Random.insideUnitCircle * 1;
    //            pos.y += 5; // hattuvakio
    //            var targetPos = transformRef.position + pos;

    //            var impulseVector = targetPos - startPos;
    //            //Debug.Log(impulseVector.magnitude);

    //            float impulseForce = (20 - impulseVector.magnitude) * Random.Range(1.1f, 1.3f);
    //            //Debug.Log(impulseForce);

    //            var rbody = note.GetComponent<Rigidbody2D>();
    //            rbody.simulated = true;
    //            rbody.AddForce(Vector2.up * impulseForce, ForceMode2D.Impulse);   // Up Force
    //            rbody.AddForce(impulseVector, ForceMode2D.Impulse);               // Left / Right Force

    //            Debug.DrawLine(startPos, targetPos, Color.red, 100f);
    //        }

    //        yield return 0;
    //    }
    //}
}
