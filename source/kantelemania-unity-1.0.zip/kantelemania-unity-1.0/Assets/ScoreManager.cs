using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.Feedbacks;
using MoreMountains.Tools;

using UnityAtoms.BaseAtoms;

namespace GGJ
{
    public class ScoreManager : MonoBehaviour
    {
        float currentScore { get; set; }

        [Header("Perfect hit")]
        [SerializeField] private float perfectThreshold;
        [SerializeField] private float perfectScore;
        [SerializeField] private string perfectFeedback;

        [Header("Good hit")]
        [SerializeField] private float goodThreshold;
        [SerializeField] private float goodScore;
        [SerializeField] private string goodFeedback;

        [Header("Misses")]
        [SerializeField] private string tooEarlyFeedback;
        [SerializeField] private string tooLateFeedback;
        [SerializeField] private float missScore;

        [Header("Feedbacks")]
        [SerializeField] private MMF_Player floatingTextFeedback;
        private MMF_FloatingText floatingText;

        [Header("Progress bar")]
        [SerializeField] private MMProgressBar progressBar;

        bool Hype = false;
        [SerializeField] BoolEvent HypeEvent;
        [SerializeField] VoidEvent GameOverEvent;

        void Start() 
        {
            Time.timeScale = 1;

            if (perfectThreshold <= 0 || goodThreshold <= 0)
            {
                Debug.LogError("ScoreManager: Perfect and Good note thresholds have to be larger than 0!");
            }

            floatingText = floatingTextFeedback.GetFeedbackOfType<MMF_FloatingText>();

            currentScore = 40;
            progressBar.SetBar(currentScore, 0, 100);
        }

        public void OnNoteExplode(float diff)
        {
            CalculateNoteHitResult(diff);
        }

        public void DecreaseScoreEventHandling(float minus)
        {
            currentScore -= minus;
            if (currentScore < 0) {
                currentScore = 0;
                Time.timeScale = 0;
                GameOverEvent.Raise();
            }

            progressBar.UpdateBar(currentScore, 0, 100);
            CheckHypeStatus();
        }

        private void CalculateNoteHitResult(float diff)
        {
            //float absDiff = Mathf.Abs(diff);
            //float scoreChange;
            //string feedback;

            /*
            if (absDiff <= perfectThreshold)
            {
                scoreChange = perfectScore;
                feedback = perfectFeedback;
            }
            else if (absDiff <= goodThreshold)
            {
                scoreChange = goodScore;
                feedback = goodFeedback;
            }
            else
            {
                scoreChange = missScore;
                if (diff < 0f)
                {
                    feedback = tooEarlyFeedback;
                }
                else
                {
                    feedback = tooLateFeedback;
                }
            }
            */

            if (currentScore < 100)
            {
                currentScore += 1;
                // scoreChange;
                //floatingText.Value = feedback + " (" + absDiff + ")";
                //floatingTextFeedback.PlayFeedbacks();

                progressBar.UpdateBar(currentScore, 0, 100);
                CheckHypeStatus();
            }
        }

        void CheckHypeStatus()
        {
            if (currentScore > 70 && !Hype)
            {
                Hype = true;
                HypeEvent.Raise(true);
            }
            else if (currentScore < 70 && Hype)
            {
                Hype = false;
                HypeEvent.Raise(false);
            }
        }
    }   
}

