using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.Feedbacks;

public class HypeEffectController : MonoBehaviour
{
    private bool hype = false;
    [SerializeField] private MMF_Player feedback;

    public void OnBeat()
    {
        if (hype)
        {
            feedback?.PlayFeedbacks();
        }
    }

    public void OnHypeChange(bool hype)
    {
        this.hype = hype;
    }
}
