using System.Collections.Generic;
using UnityEngine;
using UnityAtoms.BaseAtoms;

[CreateAssetMenu(fileName = "GameState", menuName = "Data/NoteCombo")]
public class NoteCombo : ScriptableObject
{
    public List<Note> notes;
}

[System.Serializable]
public class Note {
    public int explodeBeatDelay;
    public AudioClip playOnExplode;
}