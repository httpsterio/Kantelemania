using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "GameElements", menuName = "Data/GameElements")]
public class GameElements : ScriptableObject
{
    public Sprite[] ArrowSprites;
    public AudioClip[] NoteSounds;
    public AudioClip[] MissSound;
}

