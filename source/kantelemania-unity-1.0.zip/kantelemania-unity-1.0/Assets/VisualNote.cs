using UnityEngine;
using UnityAtoms.BaseAtoms;
using MoreMountains.Feedbacks;
using System.Collections;

namespace GGJ
{
    public enum NoteDirection : int
    {
        Up = 0,
        Down = 1,
        Left = 2,
        Right = 3
    }

    public class VisualNote : MonoBehaviour
    {
        public float explodesOnBeat = 0;
        public AudioClip playOnExplode;
        [SerializeField] private AudioSource audioSource;

        public float lateThreshold;

        [SerializeField] private GameObject timingCircle;
        //private Transform circleTransform;
        //private SpriteRenderer circleRenderer;
        public float circleStartDistance = 3f;

        public SpriteRenderer cicleTargetTimingRenderer;

        public bool inactive = false;

        [SerializeField] GameObjectEvent noteExpiredEvent;
        [SerializeField] FloatEvent noteExplodedEvent;
        [SerializeField] MMF_Player explodeFeedback;

        float delayBeforeDragChange = 2.0f;
        Rigidbody2D rBody;
        Collider2D noteCollider;

        [SerializeField] private GameObject noteSpriteGameObject;
        public NoteDirection Direction;

        void Awake()
        {
            // Still relevant?
            //circleTransform = timingCircle.GetComponent<Transform>();
            //circleRenderer = timingCircle.GetComponent<SpriteRenderer>();

            rBody = GetComponent<Rigidbody2D>();
            noteCollider = rBody.GetComponent<Collider2D>();
        }

        void Update() 
        {
            if (inactive)
            {
                rBody.drag = 0.0f;
                CheckIfInCameraSightAndRemove();
                return;
            }

            //TimingCircleHandling();

            // Make notes float after delay
            if (delayBeforeDragChange < 0 || transform.position.y > 0)
            {
                if (rBody.velocity.y > 15)
                    rBody.drag += (Time.deltaTime * 5);
                else if (rBody.velocity.y > 10)
                    rBody.drag += (Time.deltaTime * 3);
                else
                    rBody.drag += Time.deltaTime;
            }
            else
            {
                if(rBody.simulated)
                    delayBeforeDragChange -= Time.deltaTime;
            }

            if (delayBeforeDragChange < 0 && !inactive)
                inactive = true;
        }

        public void Explode()
        {
            // OLD
            //float diff = BeatManager.instance.CheckBeatProximity(explodesOnBeat);
            //noteExplodedEvent.Raise(diff);

            noteExplodedEvent.Raise(0.0f);

            //audioSource.PlayOneShot(playOnExplode, 1);

            audioSource.PlayOneShot(GamePrefabs.Instance.GameElements.NoteSounds[Random.Range(0, GamePrefabs.Instance.GameElements.NoteSounds.Length)], 1);
            explodeFeedback?.PlayFeedbacks();
            StartCoroutine(FadeOut(0.5f));
            //inactive = true;

            //cicleTargetTimingRenderer.gameObject.SetActive(false);
        }

        IEnumerator FadeOut(float duration)
        {
            var sprite = noteSpriteGameObject.GetComponent<SpriteRenderer>();
            var baseAlpha = sprite.color.a;
            float timer = 0.1f;
            while (duration > timer)
            {
                var tempColor = sprite.color;
                tempColor.a = Mathf.Lerp(baseAlpha, 0, timer / duration);
                sprite.color = tempColor;

                timer += Time.deltaTime;
                yield return 0;
            }
        }

        void CheckIfInCameraSightAndRemove()
        {
            // Check if not in camera sight
            Plane[] planes = GeometryUtility.CalculateFrustumPlanes(Camera.main);
            if (!GeometryUtility.TestPlanesAABB(planes, noteCollider.bounds))
            {
                noteExpiredEvent.Raise(this.gameObject);
                Destroy(gameObject);
            }
        }

        public void SetDirection(NoteDirection direction)
        {
            // NOTE: Top is default value
            /*
            if (direction == NoteDirection.Left)
                noteSpriteGameObject.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            else if(direction == NoteDirection.Right)
                noteSpriteGameObject.transform.rotation = Quaternion.Euler(0f, 0f, -90f);
            else if(direction == NoteDirection.Down)
                noteSpriteGameObject.transform.rotation = Quaternion.Euler(0f, 0f, -180f);
            else
                noteSpriteGameObject.transform.rotation = Quaternion.Euler(0f, 0f, 0f);
            */

            //noteSpriteGameObject.GetComponent<SpriteRenderer>().sprite = GamePrefabs.Instance.ArrowSprites[(int)direction];
            noteSpriteGameObject.GetComponent<SpriteRenderer>().sprite = GamePrefabs.Instance.GameElements.ArrowSprites[(int)direction];
            Direction = direction;
        }

        // DEPRECATED UNDER

        //public void OnBeatChange(int beatNumber)
        //{
        //    if (inactive) return;

        //    if (beatNumber > explodesOnBeat + lateThreshold)
        //    {
        //        //noteExpiredEvent.Raise(this.gameObject);
        //        inactive = true;

        //        //cicleTargetTimingRenderer.gameObject.SetActive(false);
        //    }
        //}

        //void TimingCircleHandling()
        //{
        //    float songPosition = BeatManager.instance.SongPositionInBeats;
        //    float distance = (float)explodesOnBeat - songPosition;

        //    if (distance < circleStartDistance)
        //    {
        //        float circleScale = Mathf.Lerp(0.5f, 2.0f, distance / circleStartDistance);
        //        float circleAlpha = Mathf.Lerp(1, 0, distance / circleStartDistance);

        //        circleTransform.localScale = new Vector3(circleScale, circleScale, 1);

        //        if (circleScale < 0.55f)
        //        {
        //            circleRenderer.color = new Color(255, 0, 0, circleAlpha);
        //            cicleTargetTimingRenderer.gameObject.SetActive(false);
        //        }
        //        else
        //            circleRenderer.color = new Color(0, 255, 0, circleAlpha);
        //    }
        //}
    }
}
