using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrowdController : MonoBehaviour
{
    public RectTransform crowd_front;
    float posYOnUp_front = 19.0f;
    float posYOnDown_front = -170.0f;

    public RectTransform crowd_back;
    float posYOnUp_back = 108.1f;
    float posYOnDown_back = -170.0f;

    void Awake()
    {
        crowd_front.anchoredPosition = new Vector2(crowd_back.anchoredPosition.x, posYOnUp_front);
        crowd_back.anchoredPosition = new Vector2(crowd_back.anchoredPosition.x, posYOnDown_back);
    }

    public void HideBothCrowds()
    {
        StartCoroutine(SlideCrowdInOrOut(crowd_front, false, 1.0f, posYOnDown_front, posYOnUp_front));
    }

    public void OnHype(bool hype)
    {
        StartCoroutine(SlideCrowdInOrOut(crowd_back, hype, 1.0f, posYOnDown_back, posYOnUp_back));
        //StartCoroutine(SlideCrowdInOrOut(crowd_front, hype, 1.0f, posYOnDown_front, posYOnUp_front));
    }

    IEnumerator SlideCrowdInOrOut(RectTransform gameObject, bool hype, float duration, float downPos, float upPos)
    {
        float timer = 0.0f;
        float posY = 0.0f;
        while (duration > timer)
        {
            timer += Time.deltaTime;
            if(hype)
                posY = Mathf.Lerp(downPos, upPos, timer / duration);
            else
                posY = Mathf.Lerp(upPos, downPos, timer / duration);

            gameObject.anchoredPosition = new Vector2(crowd_back.anchoredPosition.x, posY);
            yield return null;
        }
    }
}
