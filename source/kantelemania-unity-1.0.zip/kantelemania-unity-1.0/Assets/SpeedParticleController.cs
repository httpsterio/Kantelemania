using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedParticleController : MonoBehaviour
{
    [SerializeField] private ParticleSystem particles;

    void Start() 
    {
        particles.Stop();
    }

    public void OnHype(bool hype)
    {
        if (hype)
        {
            particles.Play();
        }
        else
        {
            particles.Stop();
        }
    }
}
